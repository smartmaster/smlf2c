/* for VC 4.2 */
#include <math.h>
#undef complex
